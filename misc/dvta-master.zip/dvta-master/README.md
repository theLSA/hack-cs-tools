
DVTA is a Vulnerable Thick Client Application developed in C# .NET

Some of the vulnerabilities covered in this Application.

1. Insecure local data storage
2. Insecure logging
3. Weak cryptography
4. Lack of code obfuscation
5. Exposed decryption logic
6. SQL Injection
7. CSV Injection
8. Sensitive data in memory
9. DLL Hijacking
10. Clear text data in transit

Requires .NET version 4.5

More Documentation Coming soon!
