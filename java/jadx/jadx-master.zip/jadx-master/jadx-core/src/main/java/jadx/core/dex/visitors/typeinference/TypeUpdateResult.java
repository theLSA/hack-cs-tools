package jadx.core.dex.visitors.typeinference;

public enum TypeUpdateResult {
	REJECT,
	SAME,
	CHANGED
}
