using System.Windows.Controls;

namespace Example1.Extension {
	public partial class MySettingsControl : UserControl {
		public MySettingsControl() => InitializeComponent();
	}
}
