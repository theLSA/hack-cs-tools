using System.Windows.Controls;

namespace Example2.Extension {
	public partial class ToolWindowControl : UserControl {
		public ToolWindowControl() => InitializeComponent();
	}
}
